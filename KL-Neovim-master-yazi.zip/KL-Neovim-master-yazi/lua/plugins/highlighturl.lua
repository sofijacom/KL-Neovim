return {
  "rubiin/highlighturl.nvim",
  init = function()
  vim.g.highlighturl = true
  end
}
