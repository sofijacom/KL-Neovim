return {
    -- https://github.com/AntonVanAssche/music-controls.nvim
    {
        'AntonVanAssche/music-controls.nvim',
        opts = {
            -- here you can specify your default player
            -- default_player = 'spotify'
        }
    },

}
