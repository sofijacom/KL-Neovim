-- bootstrap lazy.nvim, LazyVim and your plugins
require("config.lazy")
require("config.options")

-- https://github.com/AntonVanAssche/music-controls.nvim
require('lualine').setup {
    sections = {
        lualine_x = {
            require("music-controls")._statusline,
        }
    }
}
-- Switch color scheme
-- dracula , rose-pine , rose-pine-dawn , cyberdream , peachpuff , nightfox , duskfox , Carbonfox , dayfox
-- tokyonight , catppuccin-macchiato , catppuccin-latte , github_dark_default , github_light_default, zellner , vim , elflord
vim.o.termguicolors = true
vim.cmd('colorscheme catppuccin-macchiato')

--require('wlsample.basic')
--require('wlsample.wind')
--require('wlsample.airline')
--  the animated alternative. you can toggle animation by press `<leader>u9`
--require('wlsample.airline_anim')
