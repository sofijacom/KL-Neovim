-- Options are automatically loaded before lazy.nvim startup
-- Default options that are always set: https://github.com/LazyVim/LazyVim/blob/main/lua/lazyvim/config/options.lua
-- Add any additional options here

local opt = vim.opt

opt.title = true
-- opt.relativenumber = false
opt.cursorlineopt = "number"
-- opt.fillchars = vim.tbl_extend("force", opt.fillchars:get(), { vert = " ", horiz = " " })
